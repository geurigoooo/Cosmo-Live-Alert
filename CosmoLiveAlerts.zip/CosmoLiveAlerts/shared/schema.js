const { pgTable, text, varchar } = require('drizzle-orm/pg-core');

const guildSettings = pgTable('guild_settings', {
  guildId: varchar('guild_id', { length: 255 }).primaryKey(),
  announcementChannelId: text('announcement_channel_id')
});

module.exports = { guildSettings };
