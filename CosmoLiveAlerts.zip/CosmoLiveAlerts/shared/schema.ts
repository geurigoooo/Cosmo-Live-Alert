import { pgTable, text, varchar } from 'drizzle-orm/pg-core';

export const guildSettings = pgTable('guild_settings', {
  guildId: varchar('guild_id', { length: 255 }).primaryKey(),
  announcementChannelId: text('announcement_channel_id')
});

export type GuildSettings = typeof guildSettings.$inferSelect;
export type InsertGuildSettings = typeof guildSettings.$inferInsert;
