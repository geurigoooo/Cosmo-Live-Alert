# COSMO LIVE Discord Bot

## Overview
A Discord bot that allows moderators to manually announce when artists start COSMO LIVE streams. The bot manages notification roles and sends announcements to designated channels.

## Features
- `/live-triples [member]` - Moderators can announce tripleS members going live
- `/live-artms [member]` - Moderators can announce ARTMS members going live
- `/live-idntt [member]` - Moderators can announce idntt members going live
- `/join-notifications` - Users can opt-in to receive live notifications
- `/leave-notifications` - Users can opt-out from live notifications
- Role-based permissions for moderator commands
- Automatic role creation and management

## Project Architecture
- **Technology Stack**: Node.js with discord.js v14
- **Main File**: `index.js` - Bot entry point with slash commands
- **Database**: PostgreSQL (Neon) with Drizzle ORM for persistent storage
- **Schema**: `shared/schema.js` and `shared/schema.ts` - Database models for guild settings
- **Integration**: Discord connector for authentication
- **Persistence**: Channel configurations stored in `guild_settings` table

## Setup Requirements
- Discord bot token (stored in DISCORD_TOKEN secret)
- Bot must have proper permissions on Discord server:
  - Manage Roles
  - Send Messages
  - Use Slash Commands

## Recent Changes
- **2025-10-19**: Initial project setup with Discord bot structure
- **2025-10-19**: Added PostgreSQL database with Drizzle ORM for persistent channel storage
- **2025-10-19**: Implemented `/setup-channel` command to allow custom announcement channels
- **2025-10-19**: All channel configurations now persist across bot restarts

## User Preferences
- Manual trigger system (Option 1) for live notifications
- Moderator-only access for live announcements
