# How to Deploy Your COSMO Live Bot to Bot-Hosting.net

## Step 1: Download Your Bot Files

You'll need these files from this Replit:
- `index.js` - Main bot file
- `package.json` - Dependencies list
- `shared/schema.js` - Database schema
- `shared/schema.ts` - Database schema (TypeScript)
- `drizzle.config.ts` - Database configuration

## Step 2: Set Up Free Database (Required)

Your bot needs a PostgreSQL database. Use **Neon.tech** (recommended, free):

1. Go to https://neon.tech/
2. Sign up for free account
3. Create a new project
4. Copy your connection string (looks like: `postgresql://username:password@host/database`)
5. Save this - you'll need it in Step 4

## Step 3: Upload to Bot-Hosting.net

1. Go to https://bot-hosting.net/
2. Create a free account
3. Create a new bot/application
4. Upload your bot files (or connect via GitHub)
5. Make sure to select **Node.js** as the runtime

## Step 4: Add Your Secrets

In Bot-Hosting.net, you'll need to add these environment variables:

**DISCORD_TOKEN**
- Your Discord bot token (from Discord Developer Portal)

**DATABASE_URL**
- Your Neon database connection string from Step 2

**Other Database Variables** (from your Neon connection string):
- PGHOST
- PGUSER
- PGPASSWORD
- PGDATABASE
- PGPORT

## Step 5: Install Dependencies & Push Database Schema

In Bot-Hosting.net's console/terminal, run:
```bash
npm install
npm run db:push
```

This will:
- Install all required packages (discord.js, database drivers, etc.)
- Create the database tables your bot needs

## Step 6: Start Your Bot

Start the bot using:
```bash
npm start
```

Or just use the "Start" button in Bot-Hosting.net's interface.

## Your Bot is Now Running 24/7! 🎉

The bot will:
- Stay online permanently
- Automatically restart if it crashes
- Use your Neon database for storing channel settings
- Work exactly like it does here on Replit

## Troubleshooting

**Bot won't start?**
- Check that DISCORD_TOKEN is correct
- Make sure DATABASE_URL is set properly
- Verify you ran `npm install` and `npm run db:push`

**Commands not working?**
- Wait 1-2 minutes for Discord to register slash commands
- Make sure the bot has proper permissions in your server

**Database errors?**
- Confirm your Neon database is active
- Check that `npm run db:push` completed successfully
