# COSMO Live Discord Bot

A Discord bot that helps moderators announce when artists go live on COSMO (Cosmo : the Gate app) and manages notification roles for fans.

## Features

### Slash Commands

1. **`/live-triples [member] [message]`** (Moderators Only)
   - Announces that a tripleS member is going live on COSMO
   - Pings all users with the notification role
   - Sends a beautiful embed message with artist info
   - Optional custom message parameter
   - **Permissions Required**: Manage Messages

2. **`/live-artms [member] [message]`** (Moderators Only)
   - Announces that an ARTMS member is going live on COSMO
   - Similar to `/live-triples` but for ARTMS members
   - **Permissions Required**: Manage Messages

3. **`/live-idntt [member] [message]`** (Moderators Only)
   - Announces that an idntt member is going live on COSMO
   - Similar to `/live-triples` but for idntt members
   - **Permissions Required**: Manage Messages

4. **`/join-notifications`** (All Users)
   - Opt-in to receive COSMO live notifications
   - Adds the "COSMO Live Alerts" role to the user

5. **`/leave-notifications`** (All Users)
   - Opt-out from COSMO live notifications
   - Removes the "COSMO Live Alerts" role from the user

6. **`/setup-channel`** (Administrators Only)
   - Sets the current channel as the announcement channel for live notifications
   - Use this command in the channel where you want announcements posted
   - **Permissions Required**: Administrator

## How It Works

1. The bot automatically creates:
   - A role called **"COSMO Live Alerts"** (pink color, mentionable)
   - A channel called **"cosmo-live-announcements"** (if it doesn't exist)

2. Users can join/leave notifications using the slash commands

3. When a moderator uses a live command (`/live-triples`, `/live-artms`, or `/live-idntt`), the bot:
   - Sends an embed message to the announcement channel
   - Pings everyone with the "COSMO Live Alerts" role
   - Displays the artist name and optional custom message

## Setup Instructions

### Prerequisites
- Node.js 20 or higher
- A Discord bot token with proper permissions
- discord.js v14

### Bot Permissions Required
When inviting the bot to your server, make sure it has these permissions:
- **Manage Roles** - To create and assign notification roles
- **Send Messages** - To post announcements
- **Manage Channels** - To create the announcement channel
- **Use Slash Commands** - To register and use commands

### Installation

1. The bot is already configured and running on Replit
2. Make sure you've added your Discord bot token to Replit Secrets as `DISCORD_TOKEN`
3. The bot will automatically start and register commands

### Inviting to Your Server

Use the OAuth2 URL Generator in Discord Developer Portal:
- **Scopes**: `bot` and `applications.commands`
- **Bot Permissions**: Select the permissions listed above

## Usage Examples

### Moderator announces a live stream:
```
/live-artms member:Heejin message:Don't miss this special performance!
/live-triples member:Yooyeon
/live-idntt member:Dohun message:Special stage today!
```

### User wants to receive notifications:
```
/join-notifications
```

### User wants to stop receiving notifications:
```
/leave-notifications
```

## Technical Details

- **Framework**: discord.js v14
- **Database**: PostgreSQL (Neon) with Drizzle ORM
- **Command Type**: Slash Commands (modern Discord standard)
- **Permission System**: Role-based with default member permissions
- **Auto-setup**: Automatically creates roles and channels as needed
- **Persistence**: Channel configurations are saved to the database and persist across bot restarts

## Support

If you encounter any issues:
1. Make sure the bot has proper permissions in your server
2. Check that the bot is online (green status)
3. Verify the DISCORD_TOKEN is correctly set in Replit Secrets
4. Check the console logs for error messages

## Notes

- Commands are registered per-server (guild) for instant updates
- The bot requires "Server Members Intent" to be enabled in Discord Developer Portal
- Slash commands may take a few minutes to appear after first inviting the bot
